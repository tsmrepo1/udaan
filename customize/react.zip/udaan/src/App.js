import axios from 'axios'
import React from 'react'

const App = () => {

  const [countries, setCountries] = React.useState([])
  const [step, setStep] = React.useState(1)
  
  const [country, setCountry] = React.useState(null)
  
  const [airports, setAirports] = React.useState([
    "Bengaluru, BLR",
    "Trivandrum, TRV",
    "Delhi, DEL",
    "Kolkata, CCU",
    "Mumbai, BOM",
    "Chennai, MAA",
    "Hyderabad, HYD",
    "Jaipur, JAI",
    "Pune, PNQ",
    "Bhubaneshwar, BBI",
    "Patna, PAT",
    "Lucknow, LKO",
    "Aurangabad, IXU",
    "Kozhikode, CCJ",
    "Nagpur, NAG",
    "Kochi, COK",
    "Amritsar, ATQ",
    "Coimbatore, CJB",
    "Trichy, TRZ",
    "Indore, IDR",
    "Varanasi, VNS",
    "Madurai, IXM",
    "Guwahati, GAU",
    "Mangalore, IXE",
    "Vadodara, BDQ",
    "Visakhapatnam, VTZ",
    "Ahmedabad, AMD",
    "Raipur, RPR",
    "Chandigarh, IXC",
    "Udaipur, UDR",
    "Goa, GOI",
    "Ranchi, IXR",
    "Jodhpur, JDH",
    "Bikaner, BKB",
    "Kishangarh, KQH",
    "Kovalam, TRV",
    "Tirupati, TIR",
    "Jaisalmer, JSA",
    "Kannur, CNN",
    "Tezpur, TEZ",
    "Siliguri, IXB",
    "Imphal, IMF",
    "Aizwal, AJL",
    "Mysore, MYQ",
    "Jorhat, JRH",
    "Dibrugarh, DIB",
    "Agartala, IXA",
    "Shillong, SHL",
    "Agra, AGR",
    "Dehradun, DED",
    "Kullu, KUU",
    "Port Blair, IXZ",
    "Nashik, ISK",
    "Leh, IXL",
    "Srinagar, SXR",
    "Bhuj, BHJ",
    "Jammu, IXJ",
    "Fatehpur, KNU",
    "Kadapa, CDP",
    "Surat, STV",
    "Vijayawada, VGA",
    "Kandla, IXY",
    "Jamnagar, JGA",
    "Porbandar, PBD",
    "Rajkot, RAJ",
    "Bokaro, BKR",
    "Jabalpur, JLR",
    "Jamshedpur, IXW",
    "Jamshedpur, IXW",
    "Bellary, BEP",
    "Belgaum, IXG",
    "Kalaburagi, GBI",
    "Hubli, HBX",
    "Satna, TNI",
    "Jabalpur, JLR",
    "Yavatmal, YTL",
    "Nanded, NDC",
    "Kolhapur, KLH",
    "Solapur, SSL",
    "Jalgaon, JLG",
    "Akola, AKD",
    "Aizawl, AJL",
    "Dimapur, DMU",
    "Jharsuguda, JRG",
    "Jeypore, PYB",
    "Pantnagar, PGH",
    "Ludhiana, LUH",
    "Kota, KTU",
    "Kanpur, KNU",
    "Gorakhpur, GOP",
    "Pithoragarh, NNS",
    "Rajahmundry, RJA",
    "Pasighat, IXT",
    "Bilaspur, PAB",
    "Diu, DIU",
    "Hisar, HSS",
    "Bokaro, BKR",
    "Jalandhar, AIP",
    "Shirdi, SAG",
    "Yavatmal, YTL",
    "Ajmer, KQH",
    "Solapur, SSL",
    "Jeypore, PYB",
    "Bathinda, BUP",
    "Pathankot, IXP",
    "Gangtok, PYG",
    "Balurghat, RGH",
    "Pithoragarh, NNS",
    "Ghaziabad, HDX",
    "Salem, SXV",
  ])

  const [person, setPerson] = React.useState({
    name: null,
    email: null,
    phone: null,
  })

  const [data, setData] = React.useState({
    country_id: null,
    country_name: null,
    date_range: null,
    partner: null,
    season: null,
    airport: null,
    date: null,
    day_count: null,
    night_count: null
  })

  React.useEffect(() => { 
    axios.get("https://udaan.thinksurfmedia.com/php/wp-content/themes/udaan/API/countries.php")
    .then(response => {
      setCountries([...response.data.countries])
    })
    .catch(console.log)
  }, [])


  const submit = (event) => { 
    event.preventDefault()

    axios.post("https://udaan.thinksurfmedia.com/php/wp-content/themes/udaan/API/submit_lead.php", {
      user_name: person.name,
      user_email: person.email,
      user_phone: person.phone,
      user_category: data.country_name,
      category_id: data.country_id,
      date_range: data.date_range,
      partner: data.partner,
      season: data.season,
      airport: data.airport,
      travelling_date: data.date
    }, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    })
      .then(response => { 
        if (response.data.status.error_code == 0) { 
          window.location.href = `https://udaan.thinksurfmedia.in/php/search/?categoryId=${data.country_id}&night=${data.night_count}&days=${data.day_count}`
        }
      })
      .catch(error => { 
        console.log(error)
        alert("Something went wrong, try again")
      })
  }

  const [searchAirport, setAirportTerm] = React.useState("")
  const [searchCountry, setCountryTerm] = React.useState("")

  return (
    <div className="outer-main-wrap">
      <div className="step-form-wrap">
        <div className="step-form-wrap__header">
          <div className="custom-container">
            <p>Now Planning Your Holiday Too</p>
            {/* <!-- Step Form Outputs - acting as a tab --> */}
            <ul className="step-form__output">
              {data.country_name && (
                <li onClick={() => setStep(1)}>
                  <a href="#" data-index="1">{data.country_name}</a>
                </li>
              )}

              {data.season && (
                <li onClick={() => setStep(2)}>
                  <a href="#" data-index="2">{data.season}</a>
                </li>
              )}

              {data.airport && (
                <li onClick={() => setStep(3)}>
                  <a href="#" data-index="3">{data.airport}</a>
                </li>
              )}

              {data.date_range && (
                <li onClick={() => setStep(4)}>
                  <a href="#" data-index="4">{data.date_range}</a>
                </li>
              )}

              {data.partner && (
                <li onClick={() => setStep(5)}>
                  <a href="#" data-index="5">{data.partner}</a>
                </li>
              )}
            </ul>

            {/* <!-- Step Form Progress --> */}
            <ul className="step-form__progress">
              {data.country_name ? <li className="active">&nbsp;</li> : <li>&nbsp;</li>}
              {data.season ? <li className="active">&nbsp;</li> : <li>&nbsp;</li>}
              {data.airport ? <li className="active">&nbsp;</li> : <li>&nbsp;</li>}
              {data.date_range ? <li className="active">&nbsp;</li> : <li>&nbsp;</li>}
              {data.partner ? <li className="active">&nbsp;</li> : <li>&nbsp;</li>}
            </ul>

            {/* <!-- Go Back Link  --> */}
            <a href="https://udaan.thinksurfmedia.com/php/" className="link--close">
              <svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 384 512"><path d="M342.6 150.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L192 210.7 86.6 105.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L146.7 256 41.4 361.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L192 301.3 297.4 406.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L237.3 256 342.6 150.6z" /></svg>
            </a>
          </div>
        </div>
        <div className="step-form-wrap__body">
          <div className="custom-container">
            <form action="#" onSubmit={(event) => submit(event)}>
              {/* <!-- Fieldset - Search and Select Destination --> */}
              <fieldset data-index="1" id="sf_destination" className={`${step == 1 && "active"}`}>
                <h3>What’s your pickfor your next vacation?</h3>

                <div className="vs-form">
                  <div className="vs-form__field">
                    <input type="text" name="sf_vacation" placeholder="Pick Your Destination" onChange={(event) => setCountryTerm(event.target.value)} />

                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 40" x="0px" y="0px">
                      <g data-name="12"><path d="M28.14,26.73l-6.4-6.4A10,10,0,0,0,6.93,6.93a10,10,0,0,0,13.4,14.81l6.4,6.4a1,1,0,0,0,1.41-1.41ZM8.34,19.66a8,8,0,1,1,11.31,0A7.95,7.95,0,0,1,8.34,19.66Z" /></g>
                    </svg>
                  </div>

                  <ul className="vs-form__item-list">
                    {countries.filter((country) =>
                      country.name.toLowerCase().includes(searchCountry.toLowerCase())
                    ).map(country => (
                      <li onClick = {event => {
                        setData({ ...data, country_id: country.id, country_name: country.name})
                        setCountry(country)
                        setStep(2)
                      }}>
                        <a href="#" data-title="{country.name}" data-id="{country.id}" key={country.id}>{country.name}</a>
                      </li>
                    ))}
                  </ul>
                </div>
              </fieldset>

              {/* <!-- Fieldset - Select Month & Date --> */}
              <fieldset data-index="2" id="sf_date" className={`${step == 2 && "active"}`}>
                <h4>Which month are you travelling?</h4>

                <ul className="month-list custom-label-list">
                  {country && country.seasons.map((season, index) => (
                    <li key={index} onClick={event => {
                      setData({ ...data, season: season.month })
                      if (data.date) {
                        setStep(3)
                      }
                    }}>
                      <input type="radio" name="sf_month" value="november" id="month_november" />
                      <label htmlFor="month_november">
                        <h5>{season.month}</h5>
                        <p className="badge">{season.type}</p>
                        <p>{season.high_temp} / {season.low_temp}</p>
                      </label>
                    </li>
                  ))}
                </ul>

                <div className="date-input-field">
                  <h4>Select Date</h4>

                  <div className="form__field">
                    <input type="date" className="form__input" required onChange={(event) => { 
                      setData({ ...data, date: event.target.value })
                      if (data.season) {
                        setStep(3)
                      }
                    }} />
                  </div>
                </div>
              </fieldset>

              {/* <!-- Fieldset - Search and Select Travelling From --> */}
              <fieldset data-index="3" id="sf_travelling_from" className={`${step == 3 && "active"}`}>
                <h4>Where are you travelling from?</h4>
                <div className="vs-form">
                  <div className="vs-form__field">
                    <input type="text" name="sf_airport" placeholder="Search Airport" onChange={(event) => setAirportTerm(event.target.value)}  />

                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 40" x="0px" y="0px">
                      <g data-name="12"><path d="M28.14,26.73l-6.4-6.4A10,10,0,0,0,6.93,6.93a10,10,0,0,0,13.4,14.81l6.4,6.4a1,1,0,0,0,1.41-1.41ZM8.34,19.66a8,8,0,1,1,11.31,0A7.95,7.95,0,0,1,8.34,19.66Z" /></g>
                    </svg>
                  </div>

                  <ul className="vs-form__item-list">
                    {airports.filter((airport) =>
                      airport.toLowerCase().includes(searchAirport.toLowerCase())
                    ).map((airport, index) => (
                      <li onClick={event => {
                        setData({ ...data, airport: airport })
                        setStep(4)
                      }}>
                        <a href="#" data-title="{airport}" key={index}>{airport}</a>
                      </li>
                    ))}
                  </ul>
                </div>
              </fieldset>

              {/* <!-- Fieldset - Duration Option --> */}
              <fieldset data-index="4" id="sf_duration" className={`${step == 4 && "active"}`}>
                <h4>What's the duration of your holiday?</h4>
                <ul className="duration-list custom-label-list">
                  {country && country.date_ranges.map((range, index) => (
                    <li onClick={event => {
                      setData({ ...data, day_count: range.day_count, night_count: range.night_count, date_range: `${range.day_count} days ${range.night_count} nights` })
                      setStep(5)
                    }}>
                      <input type="radio" name="sf_duration" id="sf_duration_1" />
                      <label htmlFor="sf_duration_1">
                        <img src="assets/images/duration_6_9_days.jpg" alt="" />
                        <h5>{range.day_count} D/ {range.night_count} N</h5>
                      </label>
                    </li>
                  ))}
                </ul>
              </fieldset>

              {/* <!-- Fieldset - Travelling With You Option --> */}
              <fieldset data-index="5" id="sf_with_option" className={`${step == 5 && "active"}`}>
                <h4>Who is travelling with you?</h4>
                <ul className="duration-list custom-label-list">
                  <li onClick={event => {
                    setData({ ...data, partner: `Couple` })
                    setStep(6)
                  }}>
                    <input type="radio" name="sf_with_option" id="sf_with_option_couple" />
                    <label htmlFor="sf_with_option_couple">
                      <img src="assets/images/travel_with_partner_de931cd6b8.png" alt="" />
                      <h5>Couple</h5>
                    </label>
                  </li>

                  <li onClick={event => {
                    setData({ ...data, partner: `Family` })
                    setStep(6)
                  }}>
                    <input type="radio" name="sf_with_option" id="sf_with_option_family" />
                    <label htmlFor="sf_with_option_family">
                      <img src="assets/images/travel_with_family_730ac41742.png" alt="" />
                      <h5>Family</h5>
                    </label>
                  </li>

                  <li onClick={event => {
                    setData({ ...data, partner: `Friends` })
                    setStep(6)
                  }}>
                    <input type="radio" name="sf_with_option" id="sf_with_option_friends" />
                    <label htmlFor="sf_with_option_friends">
                      <img src="assets/images/travel_with_friends_23d8a637c3.png" alt="" />
                      <h5>Friends</h5>
                    </label>
                  </li>

                  <li onClick={event => {
                    setData({ ...data, partner: `Solo` })
                    setStep(6)
                  }}>
                    <input type="radio" name="sf_with_option" id="sf_with_option_solo" />
                    <label htmlFor="sf_with_option_solo">
                      <img src="assets/images/travel_with_myself_8f0e425b26.png" alt="" />
                      <h5>Solo</h5>
                    </label>
                  </li>
                </ul>
              </fieldset>

              {/* <!-- Fieldset - Add Contact --> */}
              <fieldset data-index="6" id="sf_contact" className={`${step == 6 && "active"}`}>
                <h4>Please enter your details</h4>

                <div className="form__field">
                  <input type="text" name="sf_name" className="form__input" placeholder="Full Name*" required onChange={event => setPerson({...person, name: event.target.value})} />
                </div>
                <div className="form__field">
                  <input type="email" name="sf_email" className="form__input" placeholder="Email*" required onChange={event => setPerson({ ...person, email: event.target.value })} />
                </div>
                <div className="form__field">
                  <input type="tel" name="sf_phone" className="form__input" placeholder="Phone*" required onChange={event => setPerson({ ...person, phone: event.target.value })} />
                </div>
                <div className="submit-container">
                  <button type="submit">Submit</button>
                </div>
              </fieldset>
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}

export default App