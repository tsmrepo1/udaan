<?php
$url = (!empty($_SERVER['HTTPS'])) ? "https://".$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'] : "http://".$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'];
$url = $_SERVER['REQUEST_URI'];
$my_url = explode('wp-content' , $url); 
$path = $_SERVER['DOCUMENT_ROOT']."/".$my_url[0];
include_once $path . '/wp-config.php';
//include_once $path . '/wp-includes/wp-db.php';
include_once $path . '/wp-includes/pluggable.php';
global $woocommerce;
$obj = new stdClass();
//$user_id = $_REQUEST['user_id'];
//$post_id = 92;

//countries
$countries= [
	"Seasons" => [],
	"Date Ranges" => [],
	"Partner" => []
];

$countries = [];






$terms = get_terms(
array(
'taxonomy'   => 'packages_category', // Custom Post Type Taxonomy Slug
'hide_empty' =>  false,
'order'      =>  'asc'
)
);
foreach ($terms as $term) :

	$cat_name = $term->name;

	$countries["Seasons"][] = [
		"Countries Name" => $cat_name
	];

endforeach;




 



$final_arr=array('status'=>array('error_code'=>0,'message'=>'Success'),'countries'=>$countries, );

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type'); 
header('Content-Type: application/json');
echo json_encode($final_arr);

?>